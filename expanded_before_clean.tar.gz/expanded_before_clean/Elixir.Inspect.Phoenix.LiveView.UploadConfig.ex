defmodule Inspect.Phoenix.LiveView.UploadConfig do
  def inspect(struct, opts) do
    map =
      Map.take(struct, [
        :accept,
        :auto_upload?,
        :entries,
        :errors,
        :max_entries,
        :max_file_size,
        :name,
        :progress_event,
        :ref
      ])

    name = Code.Identifier.inspect_as_atom(Phoenix.LiveView.UploadConfig)
    Inspect.Any.inspect(map, name, opts)
  end

  def __impl__(:for) do
    Phoenix.LiveView.UploadConfig
  end

  def __impl__(:target) do
    Inspect.Phoenix.LiveView.UploadConfig
  end

  def __impl__(:protocol) do
    Inspect
  end
end