defmodule Inspect.Phoenix.LiveViewTest.Element do
  def inspect(struct, opts) do
    map = Map.take(struct, [:selector, :text_filter])
    name = Code.Identifier.inspect_as_atom(Phoenix.LiveViewTest.Element)
    Inspect.Any.inspect(map, name, opts)
  end

  def __impl__(:for) do
    Phoenix.LiveViewTest.Element
  end

  def __impl__(:target) do
    Inspect.Phoenix.LiveViewTest.Element
  end

  def __impl__(:protocol) do
    Inspect
  end
end