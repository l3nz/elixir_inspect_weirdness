defmodule Inspect.Credo.SourceFile do
  def inspect(source_file, _opts) do
    <<"%SourceFile<", String.Chars.to_string(source_file.filename)::binary(), ">">>
  end

  def __impl__(:for) do
    Credo.SourceFile
  end

  def __impl__(:target) do
    Inspect.Credo.SourceFile
  end

  def __impl__(:protocol) do
    Inspect
  end
end