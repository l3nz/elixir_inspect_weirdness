defmodule Inspect.Ecto.Query.DynamicExpr do
  def inspect(%Ecto.Query.DynamicExpr{binding: binding} = dynamic, opts) do
    joins =
      Enum.map(Enum.with_index(Enum.drop(binding, 1)), fn x1 ->
        %Ecto.Query.JoinExpr{
          as: nil,
          assoc: nil,
          file: nil,
          hints: [],
          line: nil,
          on: nil,
          params: [],
          prefix: nil,
          qual: nil,
          source: nil,
          ix: x1
        }
      end)

    aliases =
      Map.new(
        Enum.with_index(
          for({as, _} when :erlang.is_atom(as) <- binding) do
            as
          end
        )
      )

    query = %Ecto.Query{
      assocs: [],
      combinations: [],
      distinct: nil,
      from: nil,
      group_bys: [],
      havings: [],
      limit: nil,
      lock: nil,
      offset: nil,
      order_bys: [],
      prefix: nil,
      preloads: [],
      select: nil,
      sources: nil,
      updates: [],
      wheres: [],
      windows: [],
      with_ctes: nil,
      joins: joins,
      aliases: aliases
    }

    {expr, binding, params, subqueries, _, _} =
      Ecto.Query.Builder.Dynamic.fully_expand(query, dynamic)

    names =
      Enum.map(binding, fn
        {_, {name, _, _}} ->
          :erlang.atom_to_binary(name, :utf8)

        {name, _, _} ->
          :erlang.atom_to_binary(name, :utf8)
      end)

    query_expr = %{expr: expr, params: params, subqueries: subqueries}
    inspected = Inspect.Ecto.Query.expr(expr, :erlang.list_to_tuple(names), query_expr)

    Inspect.Algebra.container_doc(
      "dynamic(",
      [Macro.to_string(binding), inspected],
      ")",
      opts,
      fn str, _ -> str end
    )
  end

  def __impl__(:for) do
    Ecto.Query.DynamicExpr
  end

  def __impl__(:target) do
    Inspect.Ecto.Query.DynamicExpr
  end

  def __impl__(:protocol) do
    Inspect
  end
end