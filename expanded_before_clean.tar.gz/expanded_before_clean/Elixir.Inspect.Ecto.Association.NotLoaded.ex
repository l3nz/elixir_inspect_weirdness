defmodule Inspect.Ecto.Association.NotLoaded do
  def inspect(not_loaded, _opts) do
    msg = <<"association ", Kernel.inspect(not_loaded.__field__)::binary(), " is not loaded">>
    <<"#Ecto.Association.NotLoaded<", String.Chars.to_string(msg)::binary(), ">">>
  end

  def __impl__(:for) do
    Ecto.Association.NotLoaded
  end

  def __impl__(:target) do
    Inspect.Ecto.Association.NotLoaded
  end

  def __impl__(:protocol) do
    Inspect
  end
end