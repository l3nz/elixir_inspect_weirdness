defmodule Inspect.Phoenix.LiveView.Socket do
  def inspect(struct, opts) do
    map =
      Map.take(struct, [
        :assigns,
        :changed,
        :endpoint,
        :id,
        :parent_pid,
        :root_pid,
        :router,
        :view
      ])

    name = Code.Identifier.inspect_as_atom(Phoenix.LiveView.Socket)
    Inspect.Any.inspect(map, name, opts)
  end

  def __impl__(:for) do
    Phoenix.LiveView.Socket
  end

  def __impl__(:target) do
    Inspect.Phoenix.LiveView.Socket
  end

  def __impl__(:protocol) do
    Inspect
  end
end