defmodule Inspect do
  defp struct_impl_for(struct) do
    target = Module.concat(Inspect, struct)

    try do
      target.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def inspect(term, arg2) do
    impl_for!(term).inspect(term, arg2)
  end

  def impl_for!(data) do
    impl_for(data)
  end

  def impl_for(%struct{}) do
    struct_impl_for(struct)
  end

  def impl_for(data) do
    try do
      Inspect.Tuple.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.Atom.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.List.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.Map.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.BitString.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.Integer.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.Float.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.Function.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.PID.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.Port.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(data) do
    try do
      Inspect.Reference.__impl__(:target)
    rescue
      _ in [UndefinedFunctionError] ->
        Inspect.Any.__impl__(:target)
    end
  end

  def impl_for(_) do
    Inspect.Any.__impl__(:target)
  end

  def __protocol__(:module) do
    Inspect
  end

  def __protocol__(:functions) do
    [inspect: 2]
  end

  def __protocol__(:consolidated?) do
    false
  end

  def __protocol__(:impls) do
    :not_consolidated
  end
end