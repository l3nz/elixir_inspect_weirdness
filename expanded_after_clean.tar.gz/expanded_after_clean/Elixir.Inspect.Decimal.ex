defmodule Inspect.Decimal do
  def inspect(dec, _opts) do
    <<"#Decimal<", Decimal.to_string(dec)::binary(), ">">>
  end

  def __impl__(:for) do
    Decimal
  end

  def __impl__(:target) do
    Inspect.Decimal
  end

  def __impl__(:protocol) do
    Inspect
  end
end