defmodule Inspect.Phoenix.LiveDashboard.PageLive do
  def inspect(struct, opts) do
    map = Map.take(struct, [])
    name = Code.Identifier.inspect_as_atom(Phoenix.LiveDashboard.PageLive)
    Inspect.Any.inspect(map, name, opts)
  end

  def __impl__(:for) do
    Phoenix.LiveDashboard.PageLive
  end

  def __impl__(:target) do
    Inspect.Phoenix.LiveDashboard.PageLive
  end

  def __impl__(:protocol) do
    Inspect
  end
end