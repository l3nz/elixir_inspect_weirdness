defmodule Inspect.Phoenix.LiveViewTest.View do
  def inspect(struct, opts) do
    map = Map.take(struct, [:endpoint, :id, :module, :pid])
    name = Code.Identifier.inspect_as_atom(Phoenix.LiveViewTest.View)
    Inspect.Any.inspect(map, name, opts)
  end

  def __impl__(:for) do
    Phoenix.LiveViewTest.View
  end

  def __impl__(:target) do
    Inspect.Phoenix.LiveViewTest.View
  end

  def __impl__(:protocol) do
    Inspect
  end
end