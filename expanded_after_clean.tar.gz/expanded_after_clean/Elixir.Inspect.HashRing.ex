defmodule Inspect.HashRing do
  def inspect(%HashRing{ring: ring}, _opts) do
    nodes = Enum.uniq(Enum.map(:gb_trees.to_list(ring), fn {_, n} -> n end))
    <<"#<Ring", Kernel.inspect(nodes)::binary(), ">">>
  end

  def __impl__(:for) do
    HashRing
  end

  def __impl__(:target) do
    Inspect.HashRing
  end

  def __impl__(:protocol) do
    Inspect
  end
end