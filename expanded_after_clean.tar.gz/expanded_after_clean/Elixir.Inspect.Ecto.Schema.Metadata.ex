defmodule Inspect.Ecto.Schema.Metadata do
  def inspect(metadata, opts) do
    %{source: source, prefix: prefix, state: state, context: context} = metadata

    entries =
      for(entry <- [state, prefix, source, context], :erlang."/="(entry, nil)) do
        Inspect.Algebra.to_doc(entry, opts)
      end

    Inspect.Algebra.concat(
      :erlang.++(["#Ecto.Schema.Metadata<"], :erlang.++(Enum.intersperse(entries, ", "), [">"]))
    )
  end

  def __impl__(:for) do
    Ecto.Schema.Metadata
  end

  def __impl__(:target) do
    Inspect.Ecto.Schema.Metadata
  end

  def __impl__(:protocol) do
    Inspect
  end
end