defmodule Inspect.Ecto.Changeset do
  defp to_struct(%{__struct__: struct}, _opts) do
    <<"#", Kernel.inspect(struct)::binary(), "<>">>
  end

  defp to_struct(other, opts) do
    Inspect.Algebra.to_doc(other, opts)
  end

  def inspect(%Ecto.Changeset{data: data} = changeset, opts) do
    list =
      for(attr <- [:action, :changes, :errors, :data, :valid?]) do
        {attr, Map.get(changeset, attr)}
      end

    redacted_fields =
      case(data) do
        %type{__meta__: _} ->
          type.__schema__(:redact_fields)

        _ ->
          []
      end

    Inspect.Algebra.container_doc("#Ecto.Changeset<", list, ">", opts, fn
      {:action, action}, opts ->
        Inspect.Algebra.concat("action: ", Inspect.Algebra.to_doc(action, opts))

      {:changes, changes}, opts ->
        Inspect.Algebra.concat(
          "changes: ",
          Inspect.Algebra.to_doc(filter(changes, redacted_fields), opts)
        )

      {:data, data}, _opts ->
        Inspect.Algebra.concat("data: ", to_struct(data, opts))

      {:errors, errors}, opts ->
        Inspect.Algebra.concat("errors: ", Inspect.Algebra.to_doc(errors, opts))

      {:valid?, valid?}, opts ->
        Inspect.Algebra.concat("valid?: ", Inspect.Algebra.to_doc(valid?, opts))
    end)
  end

  defp filter(changes, redacted_fields) do
    Enum.reduce(redacted_fields, changes, fn redacted_field, changes ->
      case(:maps.is_key(redacted_field, changes)) do
        x when :erlang.orelse(:erlang."=:="(x, false), :erlang."=:="(x, nil)) ->
          changes

        _ ->
          :maps.put(redacted_field, "**redacted**", changes)
      end
    end)
  end

  def __impl__(:for) do
    Ecto.Changeset
  end

  def __impl__(:target) do
    Inspect.Ecto.Changeset
  end

  def __impl__(:protocol) do
    Inspect
  end
end