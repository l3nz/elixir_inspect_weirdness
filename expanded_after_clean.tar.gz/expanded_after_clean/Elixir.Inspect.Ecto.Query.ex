defmodule Inspect.Ecto.Query do
  defp windows(windows, names) do
    Enum.map(windows, fn x1 -> window(x1, names) end)
  end

  defp window({name, %{expr: definition} = part}, names) do
    {:windows,
     <<"[", String.Chars.to_string(name)::binary(), ": ", expr(definition, names, part)::binary(),
       "]">>}
  end

  defp unmerge_fragments([{:raw, s}, {:expr, v} | t], frag, args, names, part) do
    unmerge_fragments(
      t,
      <<frag::binary(), s::binary(), "?">>,
      [expr(v, names, part) | args],
      names,
      part
    )
  end

  defp unmerge_fragments([raw: s], frag, args, _names, _part) do
    Enum.join([Kernel.inspect(<<frag::binary(), s::binary()>>) | Enum.reverse(args)], ", ")
  end

  defp type_to_expr({composite, type}) do
    {composite, type_to_expr(type)}
  end

  defp type_to_expr({part, type}) do
    {{:., [], [{:&, [], [part]}, type]}, [], []}
  end

  defp type_to_expr(type) do
    type
  end

  def to_string(query) do
    Enum.map_join(to_list(query), ",\n  ", fn
      {key, string} ->
        <<:erlang.atom_to_binary(key, :utf8)::binary(), ": ", string::binary()>>

      string ->
        string
    end)
  end

  defp to_list(query) do
    names = :erlang.list_to_tuple(generate_names(generate_letters(collect_sources(query))))
    from = bound_from(query.from, binding(names, 0))
    joins = joins(query.joins, names)
    preloads = preloads(query.preloads)
    assocs = assocs(query.assocs, names)
    windows = windows(query.windows, names)
    combinations = combinations(query.combinations)
    wheres = bool_exprs(%{and: :where, or: :or_where}, query.wheres, names)
    group_bys = kw_exprs(:group_by, query.group_bys, names)
    havings = bool_exprs(%{and: :having, or: :or_having}, query.havings, names)
    order_bys = kw_exprs(:order_by, query.order_bys, names)
    updates = kw_exprs(:update, query.updates, names)
    lock = kw_inspect(:lock, query.lock)
    limit = kw_expr(:limit, query.limit, names)
    offset = kw_expr(:offset, query.offset, names)
    select = kw_expr(:select, query.select, names)
    distinct = kw_expr(:distinct, query.distinct, names)

    Enum.concat([
      from,
      joins,
      wheres,
      group_bys,
      havings,
      windows,
      combinations,
      order_bys,
      limit,
      offset,
      lock,
      distinct,
      updates,
      select,
      preloads,
      assocs
    ])
  end

  defp preloads([]) do
    []
  end

  defp preloads(preloads) do
    [preload: Kernel.inspect(preloads)]
  end

  defp normalize_source(<<"Elixir.", _::binary()>> = source) do
    List.last(Module.split(source))
  end

  defp normalize_source(source) do
    source
  end

  defp maybe_on(%Ecto.Query.QueryExpr{expr: true}, _names) do
    []
  end

  defp maybe_on(%Ecto.Query.QueryExpr{} = on, names) do
    [on: expr(on, names)]
  end

  defp kw_inspect(_key, nil) do
    []
  end

  defp kw_inspect(key, val) do
    [{key, Kernel.inspect(val)}]
  end

  defp kw_exprs(key, exprs, names) do
    Enum.map(exprs, fn x1 -> {key, expr(x1, names)} end)
  end

  defp kw_expr(_key, nil, _names) do
    []
  end

  defp kw_expr(key, expr, names) do
    [{key, expr(expr, names)}]
  end

  defp kw_as_and_prefix(%{as: as, prefix: prefix}) do
    :erlang.++(kw_inspect(:as, as), kw_inspect(:prefix, prefix))
  end

  defp json_expr_path_to_expr(expr, path) do
    Enum.reduce(path, expr, fn element, acc -> {{:., [], [Access, :get]}, [], [acc, element]} end)
  end

  defp joins(joins, names) do
    Enum.flat_map(Enum.with_index(joins), fn {expr, ix} ->
      join(
        expr,
        binding(
          names,
          case(expr.ix) do
            x when :erlang.orelse(:erlang."=:="(x, false), :erlang."=:="(x, nil)) ->
              :erlang.+(ix, 1)

            x ->
              x
          end
        ),
        names
      )
    end)
  end

  defp join_sources(joins) do
    Enum.map(Enum.sort_by(joins, fn x1 -> x1.ix end), fn
      %Ecto.Query.JoinExpr{assoc: {_var, assoc}} ->
        assoc

      %Ecto.Query.JoinExpr{source: {:fragment, _, _}} ->
        "fragment"

      %Ecto.Query.JoinExpr{source: %Ecto.Query{from: from}} ->
        from_sources(from.source)

      %Ecto.Query.JoinExpr{source: source} ->
        from_sources(source)
    end)
  end

  defp join_qual(:inner) do
    :join
  end

  defp join_qual(:inner_lateral) do
    :join_lateral
  end

  defp join_qual(:left) do
    :left_join
  end

  defp join_qual(:left_lateral) do
    :left_join_lateral
  end

  defp join_qual(:right) do
    :right_join
  end

  defp join_qual(:full) do
    :full_join
  end

  defp join_qual(:cross) do
    :cross_join
  end

  defp join(%Ecto.Query.JoinExpr{qual: qual, assoc: {ix, right}, on: on} = join, name, names) do
    string =
      <<String.Chars.to_string(name)::binary(), " in assoc(",
        String.Chars.to_string(binding(names, ix))::binary(), ", ",
        Kernel.inspect(right)::binary(), ")">>

    :erlang.++(
      [{join_qual(qual), string}],
      :erlang.++(kw_as_and_prefix(join), maybe_on(on, names))
    )
  end

  defp join(
         %Ecto.Query.JoinExpr{qual: qual, source: {:fragment, _, _} = source, on: on} =
           join = part,
         name,
         names
       ) do
    string =
      <<String.Chars.to_string(name)::binary(), " in ",
        String.Chars.to_string(expr(source, names, part))::binary()>>

    :erlang.++(
      [{join_qual(qual), string}],
      :erlang.++(kw_as_and_prefix(join), on: expr(on, names))
    )
  end

  defp join(%Ecto.Query.JoinExpr{qual: qual, source: source, on: on} = join, name, names) do
    string =
      <<String.Chars.to_string(name)::binary(), " in ",
        String.Chars.to_string(inspect_source(source))::binary()>>

    :erlang.++(
      [{join_qual(qual), string}],
      :erlang.++(kw_as_and_prefix(join), on: expr(on, names))
    )
  end

  defp inspect_source(%Ecto.Query{} = query) do
    <<"^", Kernel.inspect(query)::binary()>>
  end

  defp inspect_source(%Ecto.SubQuery{query: query}) do
    <<"subquery(", String.Chars.to_string(to_string(query))::binary(), ")">>
  end

  defp inspect_source({source, nil}) do
    Kernel.inspect(source)
  end

  defp inspect_source({nil, schema}) do
    Kernel.inspect(schema)
  end

  defp inspect_source({source, schema} = from) do
    Kernel.inspect(
      case(:erlang.==(source, schema.__schema__(:source))) do
        false ->
          from

        true ->
          schema
      end
    )
  end

  def inspect(query, opts) do
    list =
      Enum.map(to_list(query), fn
        {key, string} ->
          Inspect.Algebra.concat(<<:erlang.atom_to_binary(key, :utf8)::binary(), ": ">>, string)

        string ->
          string
      end)

    result = Inspect.Algebra.container_doc("#Ecto.Query<", list, ">", opts, fn str, _ -> str end)

    case(query.with_ctes) do
      %Ecto.Query.WithExpr{recursive: recursive, queries: [_ | _] = queries} ->
        with_ctes =
          Enum.map(queries, fn {name, query} ->
            cte =
              case(query) do
                %Ecto.Query{} ->
                  Inspect.Ecto.Query.inspect(query, opts)

                %Ecto.Query.QueryExpr{} ->
                  expr(query, {})
              end

            Inspect.Algebra.concat([<<"|> with_cte(\"", name::binary(), "\", as: ">>, cte, ")"])
          end)

        result =
          case(recursive) do
            x when :erlang.orelse(:erlang."=:="(x, false), :erlang."=:="(x, nil)) ->
              result

            _ ->
              Inspect.Algebra.glue(result, "\n", "|> recursive_ctes(true)")
          end

        Inspect.Algebra.concat(
          Enum.intersperse([result | with_ctes], Inspect.Algebra.break("\n"))
        )

      _ ->
        result
    end
  end

  defp generate_names(letters) do
    {names, _} =
      Enum.map_reduce(letters, 0, fn x1, x2 ->
        {<<String.Chars.to_string(x1)::binary(), String.Chars.to_string(x2)::binary()>>,
         :erlang.+(x2, 1)}
      end)

    names
  end

  defp generate_letters(sources) do
    Enum.map(sources, fn source ->
      String.downcase(String.first(normalize_source(String.Chars.to_string(source))))
    end)
  end

  defp from_sources(%Ecto.SubQuery{query: query}) do
    from_sources(query.from.source)
  end

  defp from_sources({source, schema}) do
    case(schema) do
      x when :erlang.orelse(:erlang."=:="(x, false), :erlang."=:="(x, nil)) ->
        source

      x ->
        x
    end
  end

  defp from_sources(nil) do
    "query"
  end

  defp expr_to_string({:fragment, _, [{_, _} | _] = parts}, _, names, part) do
    <<"fragment(", unmerge_fragments(parts, "", [], names, part)::binary(), ")">>
  end

  defp expr_to_string({:&, _, [ix]}, _, names, %{take: take}) do
    case(take) do
      %{^ix => {:any, fields}} when :erlang.==(ix, 0) ->
        Kernel.inspect(fields)

      %{^ix => {tag, fields}} ->
        <<String.Chars.to_string(tag)::binary(), "(", binding(names, ix)::binary(), ", ",
          Kernel.inspect(fields)::binary(), ")">>

      _ ->
        binding(names, ix)
    end
  end

  defp expr_to_string({:&, _, [ix]}, _, names, _) do
    binding(names, ix)
  end

  defp expr_to_string({:^, _, [_ix, _len]}, _, _, _part) do
    Macro.to_string({:^, [], [{:..., [], nil}]})
  end

  defp expr_to_string({:^, _, [ix]}, _, _, %{params: params}) do
    case(
      Enum.at(
        case(params) do
          x when :erlang.orelse(:erlang."=:="(x, false), :erlang."=:="(x, nil)) ->
            []

          x ->
            x
        end,
        ix
      )
    ) do
      {value, _type} ->
        <<"^", Kernel.inspect(value, charlists: :as_lists)::binary()>>

      _ ->
        "^..."
    end
  end

  defp expr_to_string({{:., _, [_, _]}, _, []}, string, _, _) do
    size = :erlang.byte_size(string)
    :binary.part(string, 0, :erlang.-(size, 2))
  end

  defp expr_to_string({:type, [], [expr, type]}, _string, names, part) do
    <<"type(", String.Chars.to_string(expr(expr, names, part))::binary(), ", ",
      String.Chars.to_string(expr(type_to_expr(type), names, part))::binary(), ")">>
  end

  defp expr_to_string(%Ecto.Query.Tagged{value: value, tag: nil}, _, _names, _) do
    Kernel.inspect(value)
  end

  defp expr_to_string(%Ecto.Query.Tagged{value: value, tag: tag}, _, names, part) do
    expr({:type, [], [value, tag]}, names, part)
  end

  defp expr_to_string({:json_extract_path, _, [expr, path]}, _, names, part) do
    expr(json_expr_path_to_expr(expr, path), names, part)
  end

  defp expr_to_string({:{}, [], [:subquery, i]}, _string, _names, %Ecto.Query.BooleanExpr{
         subqueries: subqueries
       }) do
    inspect_source(Enum.fetch!(subqueries, i))
  end

  defp expr_to_string(_expr, string, _, _) do
    string
  end

  def expr(expr, names, part) do
    Macro.to_string(expr, fn x1, x2 -> expr_to_string(x1, x2, names, part) end)
  end

  defp expr(%{expr: expr} = part, names) do
    expr(expr, names, part)
  end

  defp combinations(combinations) do
    Enum.map(combinations, fn {key, val} -> {key, <<"(", to_string(val)::binary(), ")">>} end)
  end

  defp collect_sources(%{from: nil, joins: joins}) do
    ["query" | join_sources(joins)]
  end

  defp collect_sources(%{from: %{source: source}, joins: joins}) do
    [from_sources(source) | join_sources(joins)]
  end

  defp bound_from(nil, name) do
    [<<"from ", String.Chars.to_string(name)::binary(), " in query">>]
  end

  defp bound_from(%{source: source} = from, name) do
    :erlang.++(
      [
        <<"from ", String.Chars.to_string(name)::binary(), " in ",
          String.Chars.to_string(inspect_source(source))::binary()>>
      ],
      kw_as_and_prefix(from)
    )
  end

  defp bool_exprs(keys, exprs, names) do
    Enum.map(exprs, fn %{expr: expr, op: op} = part ->
      {:maps.get(op, keys), expr(expr, names, part)}
    end)
  end

  defp binding(names, pos) do
    try do
      :erlang.element(:erlang.+(pos, 1), names)
    rescue
      _ in [ArgumentError] ->
        <<"unknown_binding_", String.Chars.to_string(pos)::binary(), "!">>
    end
  end

  defp assocs([], _names) do
    []
  end

  defp assocs(assocs, names) do
    [preload: expr(assocs(assocs), names, %{})]
  end

  defp assocs(assocs) do
    Enum.map(assocs, fn
      {field, {idx, []}} ->
        {field, {:&, [], [idx]}}

      {field, {idx, children}} ->
        {field, {{:&, [], [idx]}, assocs(children)}}
    end)
  end

  def __impl__(:for) do
    Ecto.Query
  end

  def __impl__(:target) do
    Inspect.Ecto.Query
  end

  def __impl__(:protocol) do
    Inspect
  end
end