defmodule Inspect.Phoenix.LiveView.Socket.AssignsNotInSocket do
  def inspect(_, _) do
    "#Phoenix.LiveView.Socket.AssignsNotInSocket<>"
  end

  def __impl__(:for) do
    Phoenix.LiveView.Socket.AssignsNotInSocket
  end

  def __impl__(:target) do
    Inspect.Phoenix.LiveView.Socket.AssignsNotInSocket
  end

  def __impl__(:protocol) do
    Inspect
  end
end