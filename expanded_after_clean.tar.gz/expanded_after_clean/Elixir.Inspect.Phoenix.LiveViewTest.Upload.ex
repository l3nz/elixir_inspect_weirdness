defmodule Inspect.Phoenix.LiveViewTest.Upload do
  def inspect(struct, opts) do
    map = Map.take(struct, [:entries, :selector])
    name = Code.Identifier.inspect_as_atom(Phoenix.LiveViewTest.Upload)
    Inspect.Any.inspect(map, name, opts)
  end

  def __impl__(:for) do
    Phoenix.LiveViewTest.Upload
  end

  def __impl__(:target) do
    Inspect.Phoenix.LiveViewTest.Upload
  end

  def __impl__(:protocol) do
    Inspect
  end
end