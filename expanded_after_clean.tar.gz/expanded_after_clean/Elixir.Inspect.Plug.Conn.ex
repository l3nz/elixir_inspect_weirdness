defmodule Inspect.Plug.Conn do
  defp no_secret_key_base(%{secret_key_base: nil} = conn) do
    conn
  end

  defp no_secret_key_base(conn) do
    %{conn | secret_key_base: :...}
  end

  defp no_adapter_data(conn, %{limit: :infinity}) do
    conn
  end

  defp no_adapter_data(%{adapter: {adapter, _}} = conn, _) do
    %{conn | adapter: {adapter, :...}}
  end

  def inspect(conn, opts) do
    Inspect.Any.inspect(no_adapter_data(no_secret_key_base(conn), opts), opts)
  end

  def __impl__(:for) do
    Plug.Conn
  end

  def __impl__(:target) do
    Inspect.Plug.Conn
  end

  def __impl__(:protocol) do
    Inspect
  end
end